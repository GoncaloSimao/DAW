import "normalize.css";
import "../css/main.css";


import React from "react";
import ReactDOM from "react-dom/client" ;


import BaseLayout from "./components/BaseLayout";



const root = ReactDOM.createRoot(document.getElementById("root") as HTMLElement);
root.render(<BaseLayout />);

