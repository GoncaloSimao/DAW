// // React imports.
// import React from "react";


// /**
//  * WelcomeView.
//  */
// const WelcomeView = () => (

//   <div style={{ position:"relative", top:"40%", textAlign:"center", color:"#ff0000" }}>
//     <h1>Welcome to MailBag!</h1>
//   </div>

// ); /* WelcomeView. */




// export default WelcomeView;

// React imports.
import React, { useState } from "react";
//import Login from "./login";


/**
 * WelcomeView.
 */
const WelcomeView = ({ state }) => {

  return (
    <div style={{ position: "relative", top: "40%", textAlign: "center", color: "#ff0000" }}>
      <h1>Welcome to Send 2 You!</h1>
      
      {/* Formulário de Login */}
      <form>
        <label>
          <input type="email" id="userEmail" value={state.userEmail} onChange={ state.fieldChangeHandler } placeholder="Email" />
        </label>
        <br />
        <label>
          <input type="password" id="userPass" value={state.userPass} onChange={ state.fieldChangeHandler }  placeholder="Password" />
        </label>
        <br />
        <button color="primary" style={{ marginTop:10 }} type="button" onClick={state.doLogin}>
          Login
        </button>
      </form>
    </div>
  );
};

export default WelcomeView;