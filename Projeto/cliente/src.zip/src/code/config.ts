export const config: { serverAddress: string} = {
  serverAddress: "http://localhost:8080",
  // serverAddress: "http://",
  // userEmail : "name@domain.com"
  //userEmail: "fortnite@ualg.pt",
};
