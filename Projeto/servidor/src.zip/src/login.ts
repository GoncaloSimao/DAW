import * as path from "path"; //aqui está a ser feito o import de todos os modulos da biblioteca path que serve para nós manipularmos paths.
import * as fs from "fs";

export interface ILogin {
  //aqui graças à interface está a ser criado um tipo para variáveis e que terão um name, um email e um _id sendo este último opcional
  userpass: string;
  useremail: string;
}

export function alterarServerInfo(login: ILogin){

    const data = fs.readFileSync(path.join(__dirname, "../server/serverInfo.json"), "utf8");
    const info = JSON.parse(data);

    info.smtp.auth.user = login.useremail;
    info.smtp.auth.pass = login.userpass;

    fs.writeFileSync(path.join(__dirname, "../server/serverInfo.json"), JSON.stringify(info, null, 2));
    return true;
}