//server config that stores the server address
export const config: { serverAddress: string} = {
  serverAddress: "http://localhost:8080",
  // serverAddress: "http://",
};
